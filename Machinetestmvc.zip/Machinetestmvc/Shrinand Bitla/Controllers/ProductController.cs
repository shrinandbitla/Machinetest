﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using PagedList;
using Shrinand_Bitla.Context;
using Shrinand_Bitla.Models;

namespace Shrinand_Bitla.Controllers
{
    public class ProductController : Controller
    {
        private context db = new context();

        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-9GGE0MG;Initial Catalog=abc;Integrated Security=True");
        // GET: Product
        public ActionResult Index(int? page)
        {
            List<Productmodel> CategoryList = new List<Productmodel>();
            DataTable dtCategory = new DataTable();
            con.Open();

            SqlDataAdapter da = new SqlDataAdapter("Select p.ProductId,p.ProductName, c.CategoryId ,c.CategoryName from Product p INNER JOIN category c ON P.CategoryId= c.CategoryId ORDER BY p.ProductId DESC", con);

            da.Fill(dtCategory);
            foreach (DataRow dr in dtCategory.Rows)
            {
                CategoryList.Add(

                    new Productmodel
                    {
                        ProductId = Convert.ToInt32(dr["ProductId"]),
                        ProductName = Convert.ToString(dr["ProductName"]),
                        CategoryId = Convert.ToInt32(dr["CategoryId"]),
                        CategoryName = Convert.ToString(dr["CategoryName"]),
                    });
            }
      
            return View(CategoryList.ToList().ToPagedList(page ?? 1, 10));
        }


        [HttpGet]
        public ActionResult Create()
        {

            string q = "select CategoryId,CategoryName from category";
            SqlCommand cmd = new SqlCommand(q, con);
            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            sda.Fill(ds);
            ViewBag.category = ds.Tables[0];

            List<SelectListItem> gettitlename = new List<SelectListItem>();

            foreach (DataRow dr in ViewBag.category.Rows)
            {
                gettitlename.Add(new SelectListItem { Text = @dr["CategoryName"].ToString(), Value = @dr["CategoryName"].ToString() });

            }
            ViewBag.Abc = gettitlename;
            con.Close();
            return View(new Productmodel());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Productmodel pm)
        {
            con.Open();

            SqlCommand cmd1 = new SqlCommand("select CategoryId from category where CategoryName='" + pm.CategoryName + "'", con);
            int cid = Convert.ToInt32(cmd1.ExecuteScalar().ToString());
            string query = "Insert into Product(ProductName,CategoryId,CategoryName) Values(@ProductName,@CategoryId,@CategoryName)";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@ProductName", pm.ProductName);
            cmd.Parameters.AddWithValue("@CategoryId", cid);
            cmd.Parameters.AddWithValue("@CategoryName", pm.CategoryName);

            cmd.ExecuteNonQuery();

            return RedirectToAction("Index");

           
        }

        // GET: Product/Edit/5
        [HttpGet]
        public ActionResult Edit(int? id)
        {
            Productmodel pm = new Productmodel();
            DataTable dt = new DataTable();
            con.Open();
            string q = " select * from Product where ProductId=@ProductId";
            SqlDataAdapter sda = new SqlDataAdapter(q, con);
            sda.SelectCommand.Parameters.AddWithValue("@ProductId", id);
            sda.Fill(dt);
           
            if (dt.Rows.Count == 1)
            {
                pm.ProductId = Convert.ToInt32(dt.Rows[0][0].ToString());
                pm.ProductName = dt.Rows[0][1].ToString();
                pm.CategoryId = Convert.ToInt32(dt.Rows[0][2].ToString());
                pm.CategoryName = dt.Rows[0][3].ToString();
            }

            return View(pm);

        }

     
        [HttpPost]
        
        public ActionResult Edit(Productmodel pm)
        {
            con.Open();
            string q = "Update Product set ProductName=@ProductName,CategoryName=@CategoryName Where ProductId=@ProductId";
            SqlCommand cmd1 = new SqlCommand(q, con);
            cmd1.Parameters.AddWithValue("@ProductId", pm.ProductId);
            cmd1.Parameters.AddWithValue("@ProductName", pm.ProductName);
            //cmd1.Parameters.AddWithValue("@CategoryId",pm.CategoryId);
            cmd1.Parameters.AddWithValue("@CategoryName", pm.CategoryName);
         
            cmd1.ExecuteNonQuery();
            ViewBag.Message = "Product Updated Successfully";
            return RedirectToAction("Index");
            
        }

        public ActionResult Delete(int? id)
        {
            con.Open();
            string q = "Delete from Product Where ProductId=@ProductId";
            SqlCommand cmd1 = new SqlCommand(q, con);
            cmd1.Parameters.AddWithValue("@ProductId", id);
            cmd1.ExecuteNonQuery();
            return RedirectToAction("Index");

        }

       
       
    }
}
