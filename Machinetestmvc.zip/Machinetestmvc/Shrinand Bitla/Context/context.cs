﻿using Shrinand_Bitla.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace Shrinand_Bitla.Context
{
    public class context:DbContext
    {
        public context() : base("context")
        {

        }
        public DbSet<Productmodel> product { get; set; }

        public System.Data.Entity.DbSet<Shrinand_Bitla.Models.Categorymodel> Categorymodels { get; set; }
    }
}