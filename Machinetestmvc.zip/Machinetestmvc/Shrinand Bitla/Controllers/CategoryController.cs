﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Shrinand_Bitla.Context;
using Shrinand_Bitla.Models;

namespace Shrinand_Bitla.Controllers
{
    public class CategoryController : Controller
    {
        private context db = new context();

        // GET: Category
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-9GGE0MG;Initial Catalog=abc;Integrated Security=True");

        [HttpGet]
        public ActionResult Index( int? Page)
        {
            List<Categorymodel> CategoryList = new List<Categorymodel>();

            DataTable dtCategory = new DataTable();
            con.Open();

            SqlDataAdapter da = new SqlDataAdapter("Select * from category ORDER BY CategoryId DESC", con);

            da.Fill(dtCategory);

            foreach (DataRow dr in dtCategory.Rows)
            {
                CategoryList.Add(

                    new Categorymodel
                    {
                        CategoryId = Convert.ToInt32(dr["CategoryId"]),
                        CategoryName = Convert.ToString(dr["CategoryName"]),
                    });
            }


            return View(CategoryList);
        }

       
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult Create(Categorymodel cm)
        {

            con.Open();
            string query = "Insert into category(CategoryName) Values(@CategoryName)";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@CategoryName", cm.CategoryName);
            cmd.ExecuteNonQuery();
            return RedirectToAction("Index");
            

        }

        // GET: Category/Edit/5
        [HttpGet]
        public ActionResult Edit(int? id)
        {
            Categorymodel cm = new Categorymodel();
            DataTable dt = new DataTable();
            con.Open();
            string q = " select * from category where CategoryId=@CategoryId";
            SqlDataAdapter sda = new SqlDataAdapter(q, con);
            sda.SelectCommand.Parameters.AddWithValue("@CategoryId", id);
            sda.Fill(dt);
            //return View(categoryModel);
            if (dt.Rows.Count == 1)
            {
                cm.CategoryId = Convert.ToInt32(dt.Rows[0][0].ToString());
                cm.CategoryName = dt.Rows[0][1].ToString();
            }
            return View(cm);
        }

       
        [HttpPost]
        public ActionResult Edit( Categorymodel cm)
        {
            con.Open();
            string q = "Update category set CategoryName=@Categoryname Where CategoryId=@CategoryId";
            SqlCommand cmd1 = new SqlCommand(q, con);
            cmd1.Parameters.AddWithValue("@Categoryid", cm.CategoryId);
            cmd1.Parameters.AddWithValue("@Categoryname", cm.CategoryName);
            cmd1.ExecuteNonQuery();
            return RedirectToAction("Index");
        }

       
        public ActionResult Delete(int? id)
        {
            con.Open();
            string q = "Delete from category Where CategoryId=@CategoryId";
            SqlCommand cmd1 = new SqlCommand(q, con);
            cmd1.Parameters.AddWithValue("@CategoryId", id);
            cmd1.ExecuteNonQuery();
            return RedirectToAction("Index");
        }
       
     
    }
}
